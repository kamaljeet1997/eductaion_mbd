part of 'app_pages.dart';
// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

abstract class Routes {
  Routes._();
  static const HOME = _Paths.HOME;
  static const SPLASH = _Paths.SPLASH;
  static const CLASSES = _Paths.CLASSES;
  static const SUBJECT = _Paths.SUBJECT;
  static const STARTING = _Paths.STARTING;
  static const VIDEOPLAYER = _Paths.VIDEOPLAYER;
}

abstract class _Paths {
  _Paths._();
  static const HOME = '/home';
  static const SPLASH = '/splash';
  static const CLASSES = '/classes';
  static const SUBJECT = '/subject';
  static const STARTING = '/starting';
  static const VIDEOPLAYER = '/videoplayer';
}

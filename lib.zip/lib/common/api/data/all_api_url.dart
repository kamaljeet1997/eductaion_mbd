
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';




// String KSignUp = "register";
String KBaseURL = "http://122.160.201.198:3032/";
  String KBaseURL2 = "";
String KApp = "App_k";
String KUser = "User_k";
String KAlert = "Alerts_k";
String KAlert2 = "test_url_e2e_k/644253c6-73fc-4947-84ff-2e02612c82fc";
String KZone = "";
int Klimit = 0;
String KStore = "";
String KCounter = "Counter_k";
String KCamera = "Camera_k";
String KAdmin = "";

FToast? fToast;


/*
class RestDataSource {
  NetworkUtil _netUtil = new NetworkUtil();
  static final BASE_URL = 'http://goldexpert.v2infotech.net/api';

 */
/* Future<SignUpn> clientSignin(String phone_no,String device_ID) {
    Map<String, String> body = {
      "phone_no": phone_no,
      "device_ID":device_ID
    };
    return _netUtil.post(BASE_URL+'/Signup/login',body: body).then((dynamic res) {
      return new Signin.fromJson(res);
    });
  }*//*

}*/

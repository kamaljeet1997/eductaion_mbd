class SupportBoard {
  const SupportBoard._();
//BASE URL only working office network
  //static const String BASE_URL = 'http://10.0.8.245/erp/api/';


//BASE URL Working all Networks
  static const String ADDUSER = 'add-user';
  static const String GETUSER = 'get-user';
}
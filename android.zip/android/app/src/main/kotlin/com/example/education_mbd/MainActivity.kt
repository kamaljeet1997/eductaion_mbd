package com.education.education_mbd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
